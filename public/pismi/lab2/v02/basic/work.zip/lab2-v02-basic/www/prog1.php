<?php

declare(strict_types=1);

/**
 * Лабораторна робота № 2, програма № 1. Варіант 2.
 *
 * Обчислює два вирази індивідуального завдання й перевіряє, що при заданих
 * значеннях вони збігаються.
 *
 *     y₁ = a·cos x + b·sin x
 *     y₂ = A·sin(x + μ),   A = √(a² + b²),   μ = arcsin(a / √(a² + b²))
 *
 * Файл самодостатній: обчислення, перевірка й показ – усе тут.
 */

/** Вхідні дані з умови варіанта. */
const GIVEN_A = 5.5;
const GIVEN_B = 12.7;
const GIVEN_X = 1.28;

/**
 * Перший вираз.
 */
function y1(float $a, float $b, float $x): float
{
    $amp = sqrt($a ** 2 + $b ** 2);
    $mu = asin($a / $amp);

    return $a * cos($x) + $b * sin($x);
}

/**
 * Другий вираз.
 */
function y2(float $a, float $b, float $x): float
{
    $amp = sqrt($a ** 2 + $b ** 2);
    $mu = asin($a / $amp);

    return $amp * sin($x + $mu);
}

/**
 * Проміжні величини обчислення.
 *
 * Потрібні не для результату, а для перевірки: у журналі видно, як саме
 * один вираз переходить в інший.
 *
 * @return list<array{label: string, value: string}>
 */
function trace_values(float $a, float $b, float $x): array
{
    $amp = sqrt($a ** 2 + $b ** 2);
    $mu = asin($a / $amp);

    return [
        ['label' => 'A = √(a² + b²)', 'value' => fmt($amp)],
        ['label' => 'μ = arcsin(a / A), рад', 'value' => fmt($mu)],
        ['label' => 'A·sin μ (має дорівнювати a)', 'value' => fmt($amp * sin($mu))],
        ['label' => 'A·cos μ (має дорівнювати b)', 'value' => fmt($amp * cos($mu))],
        ['label' => 'x + μ, рад', 'value' => fmt($x + $mu)],
    ];
}

/**
 * Число для показу: дванадцять знаків після коми, без зайвих нулів.
 */
function fmt(float $value): string
{
    if ($value !== 0.0 && (abs($value) < 1e-6 || abs($value) >= 1e12)) {
        return sprintf('%.6e', $value);
    }

    return rtrim(rtrim(number_format($value, 12, '.', ''), '0'), '.') ?: '0';
}

/**
 * Чи збіглися значення.
 *
 * Обидва вирази рахуються в подвійній точності різними шляхами, тому збіг
 * до останнього біта не гарантований: порівнювати з нулем не можна. Допуск
 * береться пропорційним самій величині.
 */
function values_match(float $first, float $second): bool
{
    return abs($first - $second) <= 1e-9 * max(1.0, abs($first));
}


/** Екранування для виводу в HTML. */
function h(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$a = GIVEN_A;
$b = GIVEN_B;
$x = GIVEN_X;

$first = y1($a, $b, $x);
$second = y2($a, $b, $x);
$matched = values_match($first, $second);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ЛР2 · програма № 1 · варіант 2</title>
    <style>
        body {
            margin: 2rem auto;
            max-width: 52rem;
            padding: 0 1rem;
            font-family: Georgia, "Times New Roman", serif;
            line-height: 1.6;
            color: #1b1b1b;
        }

        h1 { font-size: 1.5rem; }

        pre, code, td, .num { font-family: "Courier New", monospace; }

        pre {
            background: #f3f3f3;
            padding: 0.75rem 1rem;
            overflow-x: auto;
        }

        table { border-collapse: collapse; }

        td, th { border: 1px solid #999; padding: 0.3rem 0.6rem; }

        .ok { color: #17692f; }

        .err { color: #a32116; }

        .hint { color: #555; font-size: 0.9rem; }

        td.axis { border: none; color: #777; text-align: center; }

        td.marked { background: #ffe9a8; font-weight: bold; text-align: center; }
    </style>
</head>
<body>

<h1>Програма № 1. Згортання суми гармонік в одну</h1>

<p>Обчислити два вирази й переконатися, що при заданих значеннях аргументів
вони дають однаковий результат.</p>

<pre>y₁ = a·cos x + b·sin x
y₂ = A·sin(x + μ),   A = √(a² + b²),   μ = arcsin(a / √(a² + b²))</pre>

<p class="hint">де a = <?= h(fmt($a)) ?> · b = <?= h(fmt($b)) ?> · x = <?= h(fmt($x)) ?> – значення з умови варіанта</p>

<h2>Результат</h2>

<table>
    <tr><td>y₁</td><td class="num"><?= h(fmt($first)) ?></td></tr>
    <tr><td>y₂</td><td class="num"><?= h(fmt($second)) ?></td></tr>
</table>

<p class="<?= $matched ? 'ok' : 'err' ?>">
    <?php if ($matched): ?>
        Значення збіглися. Розбіжність <?= h(sprintf('%.2e', abs($first - $second))) ?>
        не перевищує похибки подвійної точності.
    <?php else: ?>
        Значення розійшлися на <?= h(sprintf('%.2e', abs($first - $second))) ?>.
    <?php endif; ?>
</p>

<h2>Чому вирази рівні</h2>

<p>
    A·sin μ = a<br>
        A·cos μ = b
</p>

<p>
    Сума двох коливань однакової частоти – теж коливання тієї самої частоти, у
        якого амплітуда дорівнює A = √(a² + b²), а зсув фази μ. Журнал перевіряє це
        напряму: A·sin μ дає рівно a, а A·cos μ – рівно b, тож розкриття синуса суми
        повертає вихідний вираз.
</p>

<h2>Проміжні величини</h2>

<table>
    <?php foreach (trace_values($a, $b, $x) as $step): ?>
        <tr>
            <td><?= h($step['label']) ?></td>
            <td class="num"><?= h($step['value']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<p class="hint"><a href="prog2.php">Програма № 2</a></p>

</body>
</html>
