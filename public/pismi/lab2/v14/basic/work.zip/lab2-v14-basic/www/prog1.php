<?php

declare(strict_types=1);

/**
 * Лабораторна робота № 2, програма № 1. Варіант 14.
 *
 * Обчислює два вирази індивідуального завдання й перевіряє, що при заданих
 * значеннях вони збігаються.
 *
 *     y₁ = (√a/2 − 1/(2√a))² · ((√a − 1)/(√a + 1) − (√a + 1)/(√a − 1))
 *     y₂ = (1 − a)/√a
 *
 * Файл самодостатній: обчислення, перевірка й показ – усе тут.
 */

/** Вхідні дані з умови варіанта. */
const GIVEN_A = 50.765;

/**
 * Перший вираз.
 */
function y1(float $a): float
{
    $r = sqrt($a);
    $square = ($r / 2 - 1 / (2 * $r)) ** 2;
    $bracket = ($r - 1) / ($r + 1) - ($r + 1) / ($r - 1);

    return $square * $bracket;
}

/**
 * Другий вираз.
 */
function y2(float $a): float
{
    return (1 - $a) / sqrt($a);
}

/**
 * Проміжні величини обчислення.
 *
 * Потрібні не для результату, а для перевірки: у журналі видно, як саме
 * один вираз переходить в інший.
 *
 * @return list<array{label: string, value: string}>
 */
function trace_values(float $a): array
{
    return [
        ['label' => '√a', 'value' => fmt(sqrt($a))],
        ['label' => 'перший множник (квадрат)', 'value' => fmt((sqrt($a) / 2 - 1 / (2 * sqrt($a))) ** 2)],
        ['label' => '(a − 1)² / (4a)', 'value' => fmt(($a - 1) ** 2 / (4 * $a))],
        ['label' => 'друга дужка', 'value' => fmt((sqrt($a) - 1) / (sqrt($a) + 1) - (sqrt($a) + 1) / (sqrt($a) - 1))],
        ['label' => '−4√a / (a − 1)', 'value' => fmt(-4 * sqrt($a) / ($a - 1))],
    ];
}

/**
 * Число для показу: дванадцять знаків після коми, без зайвих нулів.
 */
function fmt(float $value): string
{
    if ($value !== 0.0 && (abs($value) < 1e-6 || abs($value) >= 1e12)) {
        return sprintf('%.6e', $value);
    }

    return rtrim(rtrim(number_format($value, 12, '.', ''), '0'), '.') ?: '0';
}

/**
 * Чи збіглися значення.
 *
 * Обидва вирази рахуються в подвійній точності різними шляхами, тому збіг
 * до останнього біта не гарантований: порівнювати з нулем не можна. Допуск
 * береться пропорційним самій величині.
 */
function values_match(float $first, float $second): bool
{
    return abs($first - $second) <= 1e-9 * max(1.0, abs($first));
}


/** Екранування для виводу в HTML. */
function h(string|int|float|null $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$a = GIVEN_A;

$first = y1($a);
$second = y2($a);
$matched = values_match($first, $second);
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ЛР2 · програма № 1 · варіант 14</title>
    <style>
        body {
            margin: 2rem auto;
            max-width: 52rem;
            padding: 0 1rem;
            font-family: Georgia, "Times New Roman", serif;
            line-height: 1.6;
            color: #1b1b1b;
        }

        h1 { font-size: 1.5rem; }

        pre, code, td, .num { font-family: "Courier New", monospace; }

        pre {
            background: #f3f3f3;
            padding: 0.75rem 1rem;
            overflow-x: auto;
        }

        table { border-collapse: collapse; }

        td, th { border: 1px solid #999; padding: 0.3rem 0.6rem; }

        .ok { color: #17692f; }

        .err { color: #a32116; }

        .hint { color: #555; font-size: 0.9rem; }

        td.axis { border: none; color: #777; text-align: center; }

        td.marked { background: #ffe9a8; font-weight: bold; text-align: center; }
    </style>
</head>
<body>

<h1>Програма № 1. Різниця квадратів у двох множниках одразу</h1>

<p>Обчислити два вирази й переконатися, що при заданих значеннях аргументів
вони дають однаковий результат.</p>

<pre>y₁ = (√a/2 − 1/(2√a))² · ((√a − 1)/(√a + 1) − (√a + 1)/(√a − 1))
y₂ = (1 − a)/√a</pre>

<p class="hint">де a = <?= h(fmt($a)) ?> – значення з умови варіанта</p>

<h2>Результат</h2>

<table>
    <tr><td>y₁</td><td class="num"><?= h(fmt($first)) ?></td></tr>
    <tr><td>y₂</td><td class="num"><?= h(fmt($second)) ?></td></tr>
</table>

<p class="<?= $matched ? 'ok' : 'err' ?>">
    <?php if ($matched): ?>
        Значення збіглися. Розбіжність <?= h(sprintf('%.2e', abs($first - $second))) ?>
        не перевищує похибки подвійної точності.
    <?php else: ?>
        Значення розійшлися на <?= h(sprintf('%.2e', abs($first - $second))) ?>.
    <?php endif; ?>
</p>

<h2>Чому вирази рівні</h2>

<p>
    (√a − 1)² − (√a + 1)² = −4√a
</p>

<p>
    Перший множник – квадрат величини (a − 1)/(2√a), другий після приведення до
        спільного знаменника дає −4√a/(a − 1). У добутку (a − 1)² скорочується з (a −
        1), а четвірки взаємно знищуються. Журнал наводить обидві згорнуті форми поряд
        із безпосередньо обчисленими, і вони збігаються.
</p>

<h2>Проміжні величини</h2>

<table>
    <?php foreach (trace_values($a) as $step): ?>
        <tr>
            <td><?= h($step['label']) ?></td>
            <td class="num"><?= h($step['value']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>

<p class="hint"><a href="prog2.php">Програма № 2</a></p>

</body>
</html>
