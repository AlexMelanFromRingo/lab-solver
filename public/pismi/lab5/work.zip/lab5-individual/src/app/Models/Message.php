<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Лист із форми зворотного зв’язку.
 */
class Message extends Model
{
    use HasFactory;

    /** @var list<string> */
    protected $fillable = ['theme', 'name', 'email', 'body', 'is_read'];

    /** @var array<string, string> */
    protected $casts = ['is_read' => 'boolean'];

    /**
     * Листи однієї теми, найновіші згори.
     */
    public function scopeOfTheme(Builder $query, string $theme): Builder
    {
        return $query->where('theme', $theme)->latest();
    }
}
