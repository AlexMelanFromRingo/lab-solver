<button {{ $attributes->merge(['type' => 'submit', 'class' => 'btn hover:border-[#d9634e] hover:bg-[#d9634e]']) }}>{{ $slot }}</button>
