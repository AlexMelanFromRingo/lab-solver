@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'space-y-1 text-[0.8125rem] text-[#d9634e]']) }}>
        @foreach ((array) $messages as $message)<li>{{ $message }}</li>@endforeach
    </ul>
@endif
