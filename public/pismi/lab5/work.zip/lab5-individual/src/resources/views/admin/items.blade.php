<x-site-layout :theme="$theme" :options="$options" title="Керування записами">
    <section class="mx-auto max-w-sheet px-6 pb-16 pt-14">
        <div class="mb-9 flex flex-wrap items-end justify-between gap-4">
            <div>
                <p class="mb-2 text-sm text-faint">Закрита частина · тема «{{ $theme['name'] }}»</p>
                <h1 class="text-4xl font-semibold tracking-tight">{{ $theme['collection']['title'] }}</h1>
            </div>
            <div class="flex gap-3">
                <a href="{{ route('messages.index') }}" class="btn">Скринька</a>
                <a href="{{ route('items.create') }}" class="btn">Додати запис</a>
            </div>
        </div>

        @if ($items->isEmpty())
            <p class="text-dim">Записів немає. Почніть з першого.</p>
        @else
            <div class="border-t hairline">
                @foreach ($items as $item)
                    <div class="flex flex-wrap items-baseline justify-between gap-4 border-b hairline py-4">
                        <div class="min-w-0 flex-1">
                            <h2 class="text-lg font-semibold">{{ $item->title }}</h2>
                            <p class="text-sm text-faint">
                                {{ $item->subtitle }} · {{ $item->meta }} ·
                                <span class="font-mono tabular-nums">{{ $item->year }}</span>
                            </p>
                        </div>
                        <div class="flex items-center gap-2">
                            <a href="{{ route('items.edit', $item) }}" class="btn btn-quiet">Змінити</a>
                            <form method="POST" action="{{ route('items.destroy', $item) }}"
                                  onsubmit="return confirm('Видалити «{{ $item->title }}»?');">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-quiet hover:text-[#d9634e]">Видалити</button>
                            </form>
                        </div>
                    </div>
                @endforeach
            </div>
        @endif
    </section>
</x-site-layout>
