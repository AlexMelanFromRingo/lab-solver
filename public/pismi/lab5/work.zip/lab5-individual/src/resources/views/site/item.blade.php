<x-site-layout :theme="$theme" :options="$options" :title="$item->title">
    <article class="mx-auto max-w-sheet px-6 pb-16 pt-20">
        <a href="{{ route('home') }}#collection" class="text-sm text-faint hover:text-accent">
            Повернутися до переліку
        </a>

        <p class="mt-8 text-sm text-faint">{{ $item->subtitle }}</p>
        <h1 class="mt-3 max-w-[20ch] text-5xl font-semibold leading-tight tracking-tight">{{ $item->title }}</h1>

        <dl class="mt-10 grid gap-8 border-y hairline py-7 sm:grid-cols-3">
            <div>
                <dt class="text-[0.8125rem] text-faint">{{ $theme['collection']['labels']['meta'] }}</dt>
                <dd class="mt-1.5 text-lg">{{ $item->meta }}</dd>
            </div>
            <div>
                <dt class="text-[0.8125rem] text-faint">{{ $theme['collection']['labels']['year'] }}</dt>
                <dd class="mt-1.5 font-mono text-lg tabular-nums text-accent">{{ $item->year }}</dd>
            </div>
            <div>
                <dt class="text-[0.8125rem] text-faint">{{ $theme['collection']['labels']['subtitle'] }}</dt>
                <dd class="mt-1.5 text-lg">{{ $item->subtitle }}</dd>
            </div>
        </dl>

        <p class="mt-10 max-w-[68ch] text-lg leading-relaxed text-dim">{{ $item->description }}</p>
    </article>
</x-site-layout>
