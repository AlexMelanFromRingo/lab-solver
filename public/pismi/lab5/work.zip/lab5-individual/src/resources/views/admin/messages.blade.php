<x-site-layout :theme="$theme" :options="$options" title="Скринька">
    <section class="mx-auto max-w-sheet px-6 pb-16 pt-14">
        <div class="mb-9 flex flex-wrap items-end justify-between gap-4">
            <div>
                <p class="mb-2 text-sm text-faint">Закрита частина · тема «{{ $theme['name'] }}»</p>
                <h1 class="text-4xl font-semibold tracking-tight">
                    Скринька
                    <span class="font-mono text-2xl text-accent">{{ $messages->where('is_read', false)->count() }}</span>
                    <span class="text-2xl text-faint">непрочитаних</span>
                </h1>
            </div>
            <a href="{{ route('items.index') }}" class="btn">До записів</a>
        </div>

        @if ($messages->isEmpty())
            <p class="text-dim">Листів ще немає. Форма на головній сторінці складе вам компанію.</p>
        @else
            <div class="grid gap-4">
                @foreach ($messages as $message)
                    <article class="panel px-7 py-6 {{ $message->is_read ? 'opacity-60' : '' }}">
                        <div class="mb-3 flex flex-wrap items-baseline justify-between gap-3">
                            <div>
                                <span class="font-semibold">{{ $message->name }}</span>
                                <span class="ml-2 text-sm text-faint">{{ $message->email }}</span>
                            </div>
                            <span class="font-mono text-[0.8125rem] tabular-nums text-faint">
                                {{ $message->created_at->format('d.m.Y H:i') }}
                            </span>
                        </div>

                        <p class="max-w-[72ch] leading-relaxed text-dim">{{ $message->body }}</p>

                        <div class="mt-4 flex gap-2">
                            @unless ($message->is_read)
                                <form method="POST" action="{{ route('messages.read', $message) }}">
                                    @csrf
                                    @method('patch')
                                    <button type="submit" class="btn btn-quiet">Позначити прочитаним</button>
                                </form>
                            @endunless
                            <form method="POST" action="{{ route('messages.destroy', $message) }}"
                                  onsubmit="return confirm('Видалити лист від {{ $message->name }}?');">
                                @csrf
                                @method('delete')
                                <button type="submit" class="btn btn-quiet hover:text-[#d9634e]">Видалити</button>
                            </form>
                        </div>
                    </article>
                @endforeach
            </div>
        @endif
    </section>
</x-site-layout>
