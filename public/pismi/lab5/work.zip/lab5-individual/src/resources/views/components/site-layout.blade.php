@props(['theme', 'options', 'title' => null])

@include('layouts.site', ['theme' => $theme, 'options' => $options, 'title' => $title, 'slot' => $slot])
