<x-site-layout :theme="$theme" :options="$options"
               :title="$item->exists ? 'Зміна запису' : 'Новий запис'">
    <section class="mx-auto max-w-3xl px-6 pb-16 pt-14">
        <a href="{{ route('items.index') }}" class="text-sm text-faint hover:text-accent">До переліку</a>

        <h1 class="mb-9 mt-6 text-4xl font-semibold tracking-tight">
            {{ $item->exists ? 'Зміна запису' : 'Новий запис' }}
        </h1>

        <form method="POST"
              action="{{ $item->exists ? route('items.update', $item) : route('items.store') }}"
              class="panel grid gap-5 px-8 py-8">
            @csrf
            @if ($item->exists) @method('patch') @endif

            @php
                $labels = $theme['collection']['labels'];
                $fields = [
                    ['title', $labels['title'], 'text'],
                    ['subtitle', $labels['subtitle'], 'text'],
                    ['meta', $labels['meta'], 'text'],
                    ['year', $labels['year'], 'number'],
                ];
            @endphp

            @foreach ($fields as [$name, $label, $type])
                <div>
                    <label for="{{ $name }}" class="mb-1.5 block text-[0.8125rem] text-faint">{{ $label }}</label>
                    <input id="{{ $name }}" name="{{ $name }}" type="{{ $type }}" class="field-input"
                           value="{{ old($name, $item->{$name}) }}" required>
                    @error($name) <p class="mt-1.5 text-[0.8125rem] text-[#d9634e]">{{ $message }}</p> @enderror
                </div>
            @endforeach

            <div>
                <label for="description" class="mb-1.5 block text-[0.8125rem] text-faint">Короткий опис</label>
                <textarea id="description" name="description" rows="4" class="field-input"
                          required>{{ old('description', $item->description) }}</textarea>
                @error('description') <p class="mt-1.5 text-[0.8125rem] text-[#d9634e]">{{ $message }}</p> @enderror
            </div>

            <div>
                <label for="position" class="mb-1.5 block text-[0.8125rem] text-faint">Порядок у переліку</label>
                <input id="position" name="position" type="number" min="0" max="999"
                       class="field-input sm:max-w-[10rem]" value="{{ old('position', $item->position ?? 0) }}">
            </div>

            <div class="flex gap-3">
                <button type="submit" class="btn">{{ $item->exists ? 'Зберегти' : 'Додати' }}</button>
                <a href="{{ route('items.index') }}" class="btn">Скасувати</a>
            </div>
        </form>
    </section>
</x-site-layout>
