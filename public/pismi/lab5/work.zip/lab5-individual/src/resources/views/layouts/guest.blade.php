<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Вхід — {{ config('app.name') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen font-sans antialiased">
    <div class="flex min-h-screen flex-col items-center justify-center px-6 py-12">
        <a href="{{ route('home') }}" class="mb-8 text-center">
            <div class="text-2xl font-semibold tracking-tight text-accent">Закрита частина</div>
            <div class="mt-1.5 text-sm text-faint">керування записами та скринька</div>
        </a>
        <div class="panel w-full max-w-md px-8 py-8">{{ $slot }}</div>
    </div>
</body>
</html>
