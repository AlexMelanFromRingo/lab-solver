<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Item;
use Illuminate\Database\Seeder;

/**
 * Наповнення сайту вмістом з опису тем.
 *
 * Записи в config/site.php – це початковий стан, а не остаточний: після
 * наповнення ними можна керувати в закритій частині сайту. Сівалка не
 * перезаписує наявні записи, тому її безпечно запускати повторно.
 */
class SiteSeeder extends Seeder
{
    public function run(): void
    {
        foreach (config('site.themes') as $key => $theme) {
            foreach (array_values($theme['collection']['items']) as $position => $row) {
                [$title, $subtitle, $meta, $year, $description] = $row;

                Item::firstOrCreate(
                    ['theme' => $key, 'title' => $title],
                    [
                        'subtitle' => $subtitle,
                        'meta' => $meta,
                        'year' => $year,
                        'description' => $description,
                        'position' => $position,
                    ]
                );
            }
        }
    }
}
