<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Листи, надіслані формою зворотного зв'язку.
 *
 * Зберігаються в базі, а не надсилаються поштою: для навчального сайту це
 * простіше й не вимагає поштового сервера. Прочитати їх можна в закритій
 * частині сайту.
 */
return new class () extends Migration {
    public function up(): void
    {
        Schema::create('messages', function (Blueprint $table): void {
            $table->id();
            $table->string('theme', 32)->index();
            $table->string('name', 120);
            $table->string('email', 160);
            $table->text('body');
            $table->boolean('is_read')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('messages');
    }
};
