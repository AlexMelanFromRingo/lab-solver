{{-- Верхня смуга: перехід між спільною дошкою та особистою сторінкою. --}}
<nav x-data="{ open: false }" class="border-b hairline">
    <div class="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <div class="flex items-center gap-8">
            <a href="{{ route('welcome') }}" class="font-mono text-2xl font-medium tracking-tighter text-brass">04</a>

            <div class="hidden gap-6 sm:flex">
                <x-nav-link :href="route('welcome')" :active="request()->routeIs('welcome')">
                    Спільна дошка
                </x-nav-link>
                @auth
                    <x-nav-link :href="route('dashboard')" :active="request()->routeIs('dashboard')">
                        Мої нотатки
                    </x-nav-link>
                @endauth
            </div>
        </div>

        <div class="flex items-center gap-5 text-sm">
            @auth
                <span class="hidden text-faint sm:inline">{{ Auth::user()->name }}</span>
                <a href="{{ route('profile.edit') }}" class="text-dim hover:text-ink">Профіль</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="text-dim hover:text-ink">Вийти</button>
                </form>
            @else
                <a href="{{ route('login') }}" class="text-dim hover:text-ink">Увійти</a>
                <a href="{{ route('register') }}" class="btn px-4 py-1.5 text-sm">Зареєструватися</a>
            @endauth
        </div>
    </div>
</nav>
