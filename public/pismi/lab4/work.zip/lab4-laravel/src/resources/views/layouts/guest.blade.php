<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Дошка повідомлень') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen font-sans antialiased">
    <div class="flex min-h-screen flex-col items-center justify-center px-6 py-12">
        <a href="/" class="mb-8 text-center">
            <div class="font-mono text-5xl font-medium leading-none tracking-tighter text-brass">04</div>
            <div class="mt-2 text-sm text-faint">Дошка повідомлень · кафедра ЕОМ</div>
        </a>

        <div class="panel w-full max-w-md px-8 py-8">
            {{ $slot }}
        </div>
    </div>
</body>
</html>
