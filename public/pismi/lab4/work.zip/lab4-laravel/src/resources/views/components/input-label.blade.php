@props(['value'])

<label {{ $attributes->merge(['class' => 'block text-[0.8125rem] text-faint']) }}>
    {{ $value ?? $slot }}
</label>
