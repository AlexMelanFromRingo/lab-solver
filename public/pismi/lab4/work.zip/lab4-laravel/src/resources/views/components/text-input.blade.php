@props(['disabled' => false])

<input @disabled($disabled) {{ $attributes->merge(['class' => 'field-input w-full']) }}>
