@props(['active'])

@php
$classes = ($active ?? false)
    ? 'text-ink border-b-2 border-brass pb-0.5'
    : 'text-dim hover:text-ink border-b-2 border-transparent pb-0.5';
@endphp

<a {{ $attributes->merge(['class' => $classes]) }}>{{ $slot }}</a>
