<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Дошка повідомлень') }}</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen font-sans antialiased">
    @include('layouts.navigation')

    @isset($header)
        <header class="border-b hairline">
            <div class="mx-auto max-w-6xl px-6 py-6">
                {{ $header }}
            </div>
        </header>
    @endisset

    <main>{{ $slot }}</main>
</body>
</html>
