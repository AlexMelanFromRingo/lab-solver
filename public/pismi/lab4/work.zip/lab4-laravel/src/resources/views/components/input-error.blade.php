@props(['messages'])

@if ($messages)
    <ul {{ $attributes->merge(['class' => 'text-[0.8125rem] text-[#d9634e] space-y-1']) }}>
        @foreach ((array) $messages as $message)
            <li>{{ $message }}</li>
        @endforeach
    </ul>
@endif
